<?php

namespace Pterodactyl\Contracts\Repository;

interface UserRepositoryInterface extends RepositoryInterface
{
}
